#include "tests.h"
#include "../Domain/Fruit.h"
#include "../Controller/FruitController.h"
#include "../Repository/FruitRepository.h"
#include <assert.h>

void test_fruit_name(Fruit fruit) {
    assert(fruit.get_name() == "Pears");
    fruit.set_name("Pear");
    assert(fruit.get_name() == "Pear");

}

void test_fruit_origin(Fruit fruit){
    assert(fruit.get_origin() == "Romania");
    fruit.set_origin("Hungary");
    assert(fruit.get_origin() == "Hungary");

}

void test_fruit_price(Fruit fruit){
    assert(fruit.get_price() == 13);
    fruit.set_price(14);
    assert(fruit.get_price() == 14);

}

void test_fruit_quantity(Fruit fruit){
    assert(fruit.getQuantity() == 500);
    fruit.setQuantity(350);
    assert(fruit.getQuantity() == 350);
}

void test_fruit_expire_date(Fruit fruit){
    assert(!fruit.getExpireDate().compare("20-04-2024"));
    fruit.setExpireDate("12-03-2025");
    assert(!fruit.getExpireDate().compare("12-03-2025"));
    assert(fruit.getExpireDate().compare("12-03-2026"));

}

void test_getter_setter_fruit(){
    Fruit fruit = Fruit("Pears", "Romania", 13, 500, "20-04-2024");
    test_fruit_name(fruit);
    test_fruit_origin(fruit);
    test_fruit_price(fruit);
    test_fruit_quantity(fruit);
    test_fruit_expire_date(fruit);
}

void test_operators_fruit(){
    Fruit fruit = Fruit("Pears", "Romania", 13, 500, "20-04-2024");
    Fruit fruit2 = Fruit("Pears", "Romania", 13, 500, "20-05-2024");

    assert(fruit < fruit2);
    assert(!(fruit2 < fruit));

    fruit2.setExpireDate("19-04-2024");
    assert(!(fruit < fruit2));
    assert(fruit2 < fruit);

    fruit2.setExpireDate("01-01-2025");
    assert(fruit < fruit2);
    assert(!(fruit2 < fruit));

    fruit2.setExpireDate("21-04-2024");
    assert(fruit < fruit2);
    assert(!(fruit2 < fruit));


}


void test_fruit(){
    test_getter_setter_fruit();
    test_operators_fruit();
}

void test_controller_show(FruitController controller){
    assert(controller.show_all().size() == 6);
    controller.delete_fruit("Apples", "Romania");
    assert(controller.show_all().size() == 5);

}

void test_controller_add(FruitController controller){
    Fruit fruit = Fruit("Pears", "Romania", 13, 500, "20-04-2024");

    controller.add(fruit);
    controller.add(fruit);

    assert(controller.show_all().size() == 7);

    fruit.set_name("Pere");
    controller.add(fruit);

    assert(controller.show_all().size() == 8);

}

void test_controller_find(FruitController controller){
    std::vector<Fruit> elems;
    elems = controller.find("Rom");
    assert(elems.size() == 3);
    elems = controller.find("");
    assert(elems.size() == controller.show_all().size());
}

void test_controller_update(FruitController controller){

    Fruit fruit = Fruit("Pere", "Romania", 13, 500, "20-04-2024");
    controller.add(fruit);
    controller.update_fruit("Pere", "Romania", 15, 200, "02-20-2025");
    FruitRepository rep = controller.getRepo();
    assert(rep.get_array()[6].get_price() == 15);
    assert(rep.get_array()[6].getQuantity() == 200);
    assert(rep.get_array()[6].get_origin().compare("Romania") == 0);
    assert(rep.get_array()[6].get_name().compare("Pere") == 0);

}

void test_controller_repo(FruitController controller){
    FruitRepository  new_repo = FruitRepository("test");

    controller.setRepo(new_repo);

    assert(controller.show_all().size() == 6);
}

void test_controller_date_sort(FruitController controller){
    std::vector<Fruit> elems;
    elems = controller.show_by_date();

    assert(elems[0].get_name().compare("Mango") == 0);
    assert(elems[1].get_origin().compare("Romania") == 0);
    assert(elems[2].get_price() == 1);

}
void test_controller(){
    FruitController controller = FruitController(FruitRepository("test"));
    test_controller_show(controller);
    test_controller_add(controller);
    test_controller_find(controller);
    test_controller_update(controller);
    test_controller_repo(controller);
    test_controller_date_sort(controller);
}

void test_repository_size(FruitRepository repo){
    assert(repo.get_array().size() == 6);
    repo.delete_fruit(1);
    assert(repo.get_array().size() == 5);

}

void test_repository_add(FruitRepository repo){
    Fruit fruit = Fruit("Pears", "Romania", 13, 500, "20-04-2024");

    repo.add(fruit);
    repo.add(fruit);

    assert(repo.get_array().size() == 8);
    fruit.set_name("Pere");
    repo.add(fruit);

    assert(repo.get_array().size() == 9);

}

void test_repository_update(FruitRepository repo){
    Fruit fruit = Fruit("Pears", "Romania", 13, 500, "20-04-2024");
    repo.add(fruit);
    std::vector<Fruit> elems = repo.get_array();
    fruit.set_name("Pere");
    repo.update_fruit(fruit, 6);
    elems = repo.get_array();
    assert(elems[6].get_name().compare("Pere") == 0);

}

void test_repository_setter(FruitRepository repo){
    std::vector<Fruit> new_elems;

    new_elems.push_back(Fruit("Pears", "Romania", 13, 500, "20-04-2024"));
    new_elems.push_back(Fruit("Pears", "Romania", 13, 500, "20-03-2024"));

    repo.setArray(new_elems);
    assert(repo.get_array().size() == 2);

    new_elems = repo.show_all_sort_by_date();

    assert(new_elems[0].getExpireDate().compare("20-03-2024") == 0);


}


void test_repository(){
    FruitRepository repo = FruitRepository("test");
    test_repository_size(repo);
    test_repository_add(repo);
    test_repository_update(repo);
    test_repository_setter(repo);
}


void test_all(){
    test_fruit();
    test_controller();
    test_repository();
}
