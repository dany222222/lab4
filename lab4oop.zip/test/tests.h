#ifndef LABOR_TEMA4_TESTS_H
#define LABOR_TEMA4_TESTS_H

void test_all();

void test_fruit();

void test_controller();

void test_repository();

#endif //LABOR_TEMA4_TESTS_H
