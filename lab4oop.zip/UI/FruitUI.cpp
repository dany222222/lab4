#include "FruitUI.h"
#include <iostream>

using namespace std;

FruitUI::FruitUI(FruitController ctrl1) : ctrl(ctrl1) {}

void FruitUI::print_menu() {
    cout << "Your options are\n";
    cout << "\t 1 - Show All\n";
    cout << "\t 2 - Add Fruit\n";
    cout << "\t 3 - Delete Fruit\n";
    cout << "\t 4 - Update Fruit\n";
    cout << "\t 5 - Find by Name or Origin\n";
    cout << "\t 6 - Filter by max quantity\n";
    cout << "\t 7 - Sort by Expire Date\n";
    cout << "\t 0 - Stop Program\n";

}

void read_variable(string& var, string variable_name){
    cout << variable_name << ": ";
    cin >> var;
    cout << endl;
}

void read_variable(int& var, string variable_name){
    cout << variable_name << ": ";
    cin >> var;
    cout << endl;
}

void FruitUI::print_add() {
    string name, origin, expire_date;
    int price, quantity;
    read_variable(name, "Name");
    read_variable(origin, "Origin");
    read_variable(price, "Price");
    read_variable(quantity, "Quantity");
    read_variable(expire_date, "Expire Date");
    ctrl.add(name, origin, price, quantity, expire_date);
}

void FruitUI::print_get_all() {
    for(Fruit i: ctrl.show_all()){
        print_fruit(i);
    }

}

void FruitUI::print_fruit(Fruit fr) {
    cout << fr.get_name() << ' ' << fr.get_origin() << ' ' << fr.get_price()  << ' ' << fr.getQuantity() <<' ' <<fr.getExpireDate() <<'\n';

}

void FruitUI::print_delete() {
    string name, origin;
    cout << "What fruit do you want to delete?" << endl;
    read_variable(name, "Name");
    read_variable(origin, "Origin");

    ctrl.delete_fruit(name, origin);
}

void FruitUI::print_update() {
    string name, origin, expire_date;
    int price, quantity;
    read_variable(name, "Name");
    read_variable(origin, "Origin");
    read_variable(price, "price");
    read_variable(quantity, "Quantity");
    read_variable(expire_date, "Expire Date");

    ctrl.update_fruit(name, origin, price, quantity, expire_date);
}

void FruitUI::print_find() {
    string filter;
    cout << "Filter: ";
    std::getline(std::cin, filter);
    vector<Fruit> filtered_elems = ctrl.find(filter);
    for(int i = 0; i < filtered_elems.size(); i++){
        print_fruit(filtered_elems[i]);
    }
}

void FruitUI::print_filter_by_quantity() {
    int max_quality;
    read_variable(max_quality, "Max Quantity");
    vector<Fruit> elems = ctrl.show_all(max_quality);
    for(int i = 0; i < elems.size(); i++){
        print_fruit(elems[i]);
    }
}

void FruitUI::print_sorted_by_date() {
    vector<Fruit> elems = ctrl.show_by_date();
    for(int i = 0; i < elems.size(); i++){
        print_fruit(elems[i]);
    }
}
