#ifndef LABOR_TEMA4_FRUITUI_H
#define LABOR_TEMA4_FRUITUI_H
#include "../Controller/FruitController.h"

class FruitUI {
private:
    /**
     * Connection to the repo
     */
    FruitController ctrl;
public:
    /**
     * Constructor and sets the controller
     * @param ctrl1
     */
    FruitUI(FruitController ctrl1);
    /**
     * Prints the menu
     */
    void print_menu();
    /**
     * Prints every element stored in the repo
     */
    void print_get_all();
    /**
     * Prints the add to add the element
     */
    void print_add();
    /**
     * Prints one fruit
     * @param fr the fruit printed
     */
    void print_fruit(Fruit fr);
    /**
     * Prints the delete menu
     */
    void print_delete();
    /**
     * Prints the update menu
     */
    void print_update();
    /**
     * Prints the find menu
     */
    void print_find();
    /**
     * Prints the filter by a maximum quantity menu
     */
    void print_filter_by_quantity();
    /**
     * Prints the ascending sorted Fruit by expire date
     */
    void print_sorted_by_date();
};


#endif //LABOR_TEMA4_FRUITUI_H
