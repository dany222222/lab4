#include "Fruit.h"
#include <sstream>
#include <vector>
#include <string>

using namespace std;

std::string Fruit::get_name() {
    return name;
}

void Fruit::set_name(std::string new_name) {
    Fruit::name = new_name;
}

std::string Fruit::get_origin() {
    return origin;
}

void Fruit::set_origin(std::string new_origin) {
    Fruit::origin = new_origin;
}

int Fruit::get_price() {
    return price;
}

void Fruit::set_price(int new_price) {
    price = new_price;
}

int Fruit::getQuantity() const {
    return quantity;
}

void Fruit::setQuantity(int quantity) {
    Fruit::quantity = quantity;
}

Fruit::Fruit(std::string add_name, std::string add_origin, int add_price, int add_quantity, std::string new_expire_date) {
    name = add_name;
    origin = add_origin;
    price = add_price;
    quantity = add_quantity;
    expire_date = new_expire_date;

}

const std::string &Fruit::getExpireDate() const {
    return expire_date;
}

void Fruit::setExpireDate(const std::string &expireDate) {
    expire_date = expireDate;
}

bool Fruit::operator<(const Fruit &obj) const {
    stringstream s1(this->getExpireDate());
    stringstream s2(obj.getExpireDate());
    string token;

    vector<string> tokens_date1;
    vector<string> tokens_date2;

    while(getline(s1,token, '-')){
        tokens_date1.push_back(token);
    }

    while(getline(s2,token, '-')){
        tokens_date2.push_back(token);
    }

    if(stoi(tokens_date2[2]) < stoi(tokens_date1[2])){
        return false;
    }
    if(stoi(tokens_date2[2]) == stoi(tokens_date1[2])) {
        if (stoi(tokens_date2[1]) < stoi(tokens_date1[1])) {
            return false;
        }
        if(stoi(tokens_date2[1]) == stoi(tokens_date1[1])) {
            if (stoi(tokens_date2[0]) < stoi(tokens_date1[0])) {
                return false;
            }
        }
    }
    return true;
}




