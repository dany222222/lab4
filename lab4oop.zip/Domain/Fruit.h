#ifndef LABOR_TEMA4_FRUIT_H
#define LABOR_TEMA4_FRUIT_H
#include <string>
#include <ctime>

class Fruit {
private:
    /**
     * Name of the Fruit
     */
    std::string name;
    /**
     * Country origin
     */
    std::string origin;
    /**
     * Selling price
     */
    int price;
    /**
     * Quantity left
     */
    int quantity;
    /**
     * Expire Date
     */
    std::string expire_date;
public:
    /**
     * Constructor for a Fruit
     * @param add_name
     * @param add_origin
     * @param add_price
     * @param add_quantity
     * @param new_expire_date
     */
    Fruit(std::string add_name, std::string add_origin, int add_price, int add_quantity, std::string new_expire_date);
    /**
     * @return quantity of a Fruit
     */
    int getQuantity() const;
    /**
     * Sets a new value for quantity
     * @param quantity
     */
    void setQuantity(int quantity);
    /**
     * @return name of the fruit
     */
    std::string get_name();
    /**
     * Setter for name
     * @param new_name the new name value
     */
    void set_name(std::string new_name);
    /**
     * @return origin
     */
    std::string get_origin();
    /**
     * Setter for the origin
     * @param new_origin the new origin value
     */
    void set_origin(std::string new_origin);
    /**
     * @return price
     */
    int get_price();
    /**
     * Sets a new price
     * @param new_price
     */
    void set_price(int new_price);
    /**
     * Getter for the expire date
     * @return the expire date
     */
    const std::string &getExpireDate() const;
    /**
     * Setter for the expire Date
     * @param expireDate the new expire date
     */
    void setExpireDate(const std::string &expireDate);
    /**
     * Overrides the < operator and using the expire date
     * @param obj
     * @return
     */
    bool operator<(const Fruit& obj) const;

};


#endif //LABOR_TEMA4_FRUIT_H
