#ifndef LABOR_TEMA4_FRUITREPOSITORY_H
#define LABOR_TEMA4_FRUITREPOSITORY_H
#include "../Domain/Fruit.h"
#include <vector>


class FruitRepository {
private:
    /**
     * Enables the storing and accessing of elements
     */
    std::vector<Fruit> array;
public:
    /**
     * Fruit Repository Repository and initializes values
     */
    FruitRepository();
    /**
     * Repository for test
     * @param test
     */
    FruitRepository(std::string test);
    /**
     * Adds a fruit to the dynamic storage
     * @param fruit
     */
    void add(Fruit fruit);
    /**
     * Deletes a fruit if it exists in the dynamic storage
     * @param fruit
     */
    void delete_fruit(int pos);
    /**
     * @return the dynamic storage that contains the fruits
     */
     /**
      * Updates a update_fruit with new data
      * @param update_fruit
      */
     void update_fruit(Fruit update_fruit, int pos);

    /**
     * Getter for the array
     * @return the array where the data is stored
     */
    std::vector<Fruit> get_array(int max = INT_MAX);
    /**
     * Setter for the array
     * @param array the new array
     */
    void setArray(const std::vector<Fruit> &array);
    /**
     * @return A vector of Fruits sorted ascending
     */
   std::vector<Fruit> show_all_sort_by_date();



};


#endif //LABOR_TEMA4_FRUITREPOSITORY_H
