#include "FruitController.h"
#include <vector>
#include <exception>
#include <iostream>
#include <algorithm>

FruitController::FruitController(FruitRepository repository) {

    repo = repository;
}

int FruitController::find_pos(std::string name, std::string origin) {
    std::vector<Fruit> elems = repo.get_array();
    for(int i = 0; i < elems.size(); i++){
        if(elems[i].get_name().compare(name) == 0 and elems[i].get_origin().compare(origin) == 0){
            return i;
        }
    }
    throw std::exception();
}

void FruitController::add(std::string name, std::string origin, int price, int quantity, std::string expire_date) {

    try{
        Fruit update_Fruit = find_by_origin_and_name(name, origin);
        update_Fruit.setQuantity(update_Fruit.getQuantity() + quantity);
        repo.update_fruit(update_Fruit, find_pos(name, origin));
    }
    catch(std::exception){
        repo.add(Fruit(name, origin, price, quantity, expire_date));
    }
}

void FruitController::add(Fruit fruit) {
    add(fruit.get_name(), fruit.get_origin(), fruit.get_price(), fruit.getQuantity(), fruit.getExpireDate());
}

void FruitController::delete_fruit(std::string name, std::string origin) {
    try{
        int pos = find_pos(name, origin);
        repo.delete_fruit(pos);

    }
    catch (std::exception){
        std::cout << "Please enter valid name and origin\n";
    }


}

Fruit FruitController::find_by_origin_and_name( std::string name, std::string origin) {
    std::vector<Fruit> elems = repo.get_array();
    for(int i = 0; i < elems.size(); i++){
        if(name.compare(elems[i].get_name()) == 0 and origin.compare(elems[i].get_origin()) == 0 ){
            return elems[i];
        }
    }
    throw std::exception();
}

const FruitRepository &FruitController::getRepo() const {
    return repo;
}

void FruitController::setRepo(const FruitRepository &repository) {
    FruitController::repo = repository;
}

std::vector<Fruit> FruitController::find(std::string filter) {
    std::vector<Fruit> filtered_elems;
    std::vector<Fruit> elems = repo.get_array();
    for(int i = 0; i < elems.size(); i++){
        if(elems[i].get_origin().find(filter) != std::string::npos or elems[i].get_name().find(filter) != std::string::npos){
            filtered_elems.push_back(elems[i]);
        }
    }
    filtered_elems = sort_by_name(filtered_elems);
    return filtered_elems;
}

std::vector<Fruit> FruitController::show_all(int max) {
    return sort_by_name(repo.get_array(max));
}

void
FruitController::update_fruit(std::string name, std::string origin, int price, int quantity, std::string expire_date) {

    repo.update_fruit(Fruit(name, origin, price, quantity, expire_date), find_pos(name, origin));

}

std::vector<Fruit> FruitController::show_by_date() {
    return repo.show_all_sort_by_date();
}


bool compareFruits(Fruit a, Fruit b){
    return a.get_name() < b.get_name();
}
std::vector<Fruit> FruitController::sort_by_name(std::vector<Fruit> sorted) {
    std::sort(sorted.begin(), sorted.end(), compareFruits);
    return sorted;
}
