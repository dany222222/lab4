#ifndef LABOR_TEMA4_FRUITCONTROLLER_H
#define LABOR_TEMA4_FRUITCONTROLLER_H
#include "../Repository/FruitRepository.h"

class FruitController {
private:
    /**
     * Connection to the repository
     */
    FruitRepository repo;
    /**
     * Finds a Fruit object by the unique identifier name and origin
     * @param name
     * @param origin
     * @return Fruit object
     */
    Fruit find_by_origin_and_name(std::string name, std::string origin );
    /**
     * Searches for the object with the unique identifier name and origin
     * @param name
     * @param origin
     * @return position of the fruit object where it is stored in the repository
     */
    int find_pos(std::string name, std::string origin);


public:
    FruitController(FruitRepository repository);
    /**
     * Adds a new Fruit
     * @param name
     * @param origin
     * @param price
     * @param quantity
     * @param expire_date
     */
    void add(std::string name, std::string origin, int price, int quantity, std::string expire_date);

    void add(Fruit fruit);

    /**
     * Deletes a fruit by its unique identifier(name and origin)
     * @param name
     * @param origin
     */
    void delete_fruit(std::string name, std::string origin);

    /**
     * Finds all fruits with the same origin
     * @param filter
     * @return
     */
    std::vector<Fruit> find(std::string filter);
    /**
     *
     */
    void update_fruit(std::string name, std::string origin, int price, int quantity, std::string expire_date);

    /**
     * @return repo
     */
    const FruitRepository &getRepo() const;

    /**
     * Sets a new repo
     * @param repo
     */
    void setRepo(const FruitRepository &repo);
    /**
     * Returns the stored values that have a smaller quantity than max
     * @param max
     * @return a vector holding the values that have a quantity smaller than max
     */
    std::vector<Fruit> show_all(int max = INT_MAX);
    /**
     * @return The Fruit values in the repository that are now sorted in ascending order by their expire date
     */
    std::vector<Fruit> show_by_date();

    std::vector<Fruit> sort_by_name(std::vector<Fruit> not_sorted);
};


#endif //LABOR_TEMA4_FRUITCONTROLLER_H
