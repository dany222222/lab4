#include <iostream>
#include "Repository/FruitRepository.h"
#include "Controller/FruitController.h"
#include "UI/FruitUI.h"
#include "test/tests.h"

void call_app(){
    FruitRepository repository;
    FruitController controller = FruitController(repository);
    FruitUI app = FruitUI(controller);

    int opt;
    bool isUsed = true;
    while(isUsed){
        app.print_menu();
        std::cin >> opt;
        switch(opt){
            case 1:
                app.print_get_all();
                break;
            case 2:
                app.print_add();
                break;
            case 3:
                app.print_delete();
                break;
            case 4:
                app.print_update();
                break;
            case 5:
                app.print_find();
                break;
            case 6:
                app.print_filter_by_quantity();
                break;
            case 7:
                app.print_sorted_by_date();
                break;
            case 0:
                isUsed = false;
                break;
            default:
                std::cout << "Please use a proper option \n";
                break;
        }
    }

}

int main() {
    test_all();
    call_app();

    return 0;
}
